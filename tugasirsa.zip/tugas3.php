<?php
$nilai = readline("Masukkan nilai ujian: ");
if ($nilai >= 60) {
  echo "Siswa lulus dengan nilai $nilai.";
} else {
  echo "Siswa tidak lulus dengan nilai $nilai.";
}
?>