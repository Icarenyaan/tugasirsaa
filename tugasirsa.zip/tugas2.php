<?php
$bilangan = readline("Masukkan bilangan bulat: ");
if ($bilangan % 2 == 0) {
  echo "Bilangan $bilangan adalah bilangan genap.";
} else {
  echo "Bilangan $bilangan adalah bilangan ganjil.";
}
?>